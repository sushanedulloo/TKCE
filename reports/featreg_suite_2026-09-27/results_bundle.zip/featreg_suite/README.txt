FEATURE REGULARISATION SUITE -- results bundle
=================================================

What was tested
  The same eight feature-regularisation arms, with every experimental factor
  held identical, on datasets spanning binary classification, multi-class
  classification and regression. The head is a convex linear model solved to
  the global optimum (logistic regression, or Ridge for regression) on the
  split bits of a frozen random forest under the out-of-bag honest protocol.

Fixed factors (identical on every dataset and arm)
  forest: 100 trees, max depth 6, min samples per leaf 5
  encoding: out-of-bag honest (training rows keep bits only from trees that
            never saw them; validation and test keep all trees)
  head: C = 0.01 (Ridge alpha = 1/(2C) = 50 for regression); for noise arms
        the penalty is rescaled by the number of stacked copies so the
        strength per original training row is unchanged
  noise: 3 independently flipped copies of the training rows, stacked
  rows: at most 16,000 per dataset; seed 0; stratified split 70/15/15

Arms
  00_baseline          all bits, no perturbation (also the raw-feature floor)
  10_unif_0.2          every bit flipped with probability 0.2
  20_ramp_0.2          flip probability grows with depth: 0.2 x depth / 5
  21_ctrl_0.16         uniform 0.16 = the same average budget as ramp 0.2
  30_drop_L5           the deepest layer deleted
  31_drop_L45          the two deepest layers deleted
  33_drop_L45_ramp02   drop depths 4,5 then ramp 0.2 over the survivors
  40_keep_L012         only depths 0, 1, 2 kept

Files
  suite_verdict.csv    one row per dataset: tree ceiling, raw-feature floor,
                       baseline train/test/gap, keep-0-2 train/test/gap, the
                       change in test, the gap ratio, and "holds" = yes when
                       keep-0-2 is within 0.01 of the baseline on test AND
                       has a smaller gap. ramp_minus_ctrl <= 0 means the depth
                       shape did not beat uniform noise at equal budget.
  suite_long.csv       every arm, every view, every split, every metric
  suite_results.xlsx   the same tables as an Excel workbook, one sheet per
                       dataset
  suite_overview.png   cross-dataset figure: change in test vs baseline per
                       arm (grey band = within 0.01), and gap / baseline gap
  suite.log            the full console log of the run
  <dataset>/summary.csv        that dataset's arms table
  <dataset>/figure.png         that dataset's test metric and gap by arm
  <dataset>/<arm>/run.log      the complete training log of that run
  <dataset>/<arm>/featreg_<dataset>.json   the machine-readable result

How to read a gap
  gap = train metric minus validation metric on the primary metric (AUC, or
  R^2 for regression), with the training metric measured on CLEAN bits so it
  is comparable between arms. A gap near zero or negative means no measurable
  overfitting. Classification tables also carry accuracy and log-loss on all
  three splits; regression tables carry RMSE and MAE on the original scale.

Reproduce
  python run_feature_reg_suite.py            (repo: github.com/sushanedulloo/TKCE)
